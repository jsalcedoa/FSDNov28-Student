package com.javaoo.calculators;

public class TrigonometricCalculator {
	public double sine(double x) {
		return 0;
	}
	
	public double cosine(double x) {
		return 0;
	}

	public double tangent(double x) {
		return 0;
	}

	public double arcsine(double x) {
		return 0;
	}

	public double arccosine(double x) {
		return 0;
	}

	public double arctangent(double x) {
		return 0;
	}
}
