package com.lq.annotations;

@MyAnnotation(id=123, name="howard")
public class UseAnnotation {
 
}
