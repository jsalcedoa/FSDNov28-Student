package com.lq.exercises;

public class TooHotException extends Exception {

	public TooHotException() {
		// TODO Auto-generated constructor stub
	}

	public TooHotException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
