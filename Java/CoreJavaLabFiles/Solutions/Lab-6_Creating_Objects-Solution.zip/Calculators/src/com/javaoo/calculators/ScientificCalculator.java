package com.javaoo.calculators;

public class ScientificCalculator {

	public static final double PI = 3.14159;
	
	private double holdValue;
	
	public double exp(double x) {
		return 0;
	}
	
	public double log(double x) {
		return 0;
	}
	
	public void putValueIntoMemory(double x) {
		holdValue = x;
	}
	
	public double getValueFromMemory() {
		return holdValue;
	}
}
