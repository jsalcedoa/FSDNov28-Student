package com.learnquest.demos;

public class WhileDemo {

	public static void main(String[] args) {
		int count = 0;
		int n = 20;
		
		while(count++ < n)
			System.out.print("*");
	}

}
