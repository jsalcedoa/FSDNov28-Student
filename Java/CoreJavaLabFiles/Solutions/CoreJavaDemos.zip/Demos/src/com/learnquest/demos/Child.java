package com.learnquest.demos;

public class Child extends Parent {

	public Child() { super(null); }
	
}
