package com.learnquest.demos;

public class Parent {

	public Parent(String n)
	{
	}

}
