package com.learnquest.demos.transport;

public class SpeedException extends Exception {
	public SpeedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
